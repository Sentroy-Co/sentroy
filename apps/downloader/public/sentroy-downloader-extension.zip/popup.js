/* Popup — aktif sekme YouTube videosu veya Instagram içeriğiyse butonu aç. */
const YT = "https://youtube.sentroy.com"
const IG = "https://instagram.sentroy.com"
const IG_CONTENT = /^\/(p|reel|reels|tv|stories)\/[^/]+/i

function targetFrom(urlStr) {
  try {
    const u = new URL(urlStr)
    const host = u.hostname
    if (host.endsWith("instagram.com")) {
      if (IG_CONTENT.test(u.pathname)) return `${IG}${u.pathname}`
      return null
    }
    if (/(^|\.)youtube\.com$/.test(host)) {
      const v = u.searchParams.get("v")
      if (v) return `${YT}/watch?v=${encodeURIComponent(v)}`
      const m = u.pathname.match(/^\/shorts\/([\w-]{6,})/)
      if (m) return `${YT}/watch?v=${encodeURIComponent(m[1])}`
    }
    if (host === "youtu.be") {
      const id = u.pathname.slice(1)
      if (id) return `${YT}/watch?v=${encodeURIComponent(id)}`
    }
  } catch (_) {
    /* yoksay */
  }
  return null
}

chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  const tab = tabs && tabs[0]
  const target = tab ? targetFrom(tab.url || "") : null
  const btn = document.getElementById("dl")
  const hint = document.getElementById("hint")
  if (target) {
    btn.disabled = false
    hint.textContent = "Ready — open this on Sentroy to download it."
    btn.addEventListener("click", () => {
      chrome.tabs.create({ url: target })
      window.close()
    })
  } else {
    btn.disabled = true
    hint.textContent = "Open a YouTube video or an Instagram reel/post, then click here."
  }
})
