# Sentroy Downloader — Chrome Extension

YouTube (watch/Shorts) ve **Instagram** (reel/gönderi/IGTV/story) sayfalarına **ikon-only kırmızı yuvarlak** bir indir butonu (FAB) ekler. Tıklayınca içeriği ilgili sentroy alt-alanında yeni sekmede açar: YouTube → MP4/MP3, Instagram → video/foto/profil. Metin yok — sadece ikon.

## Dosyalar
```
downloader-extension/
├── manifest.json     # MV3
├── content.js        # FAB enjeksiyonu + SPA navigasyon + ?v=/shorts → sentroy URL
├── content.css       # kırmızı yuvarlak FAB stili
├── popup.html        # toolbar popup (aktif videoyu indir + siteye link)
├── popup.js          # aktif sekme YouTube ise butonu aktifleştirir
└── icons/            # 16 / 48 / 128 (downloader-logo)
```

## Nasıl çalışır
- `content.js` `*://www.youtube.com/*`, `*://m.youtube.com/*`, `*://music.youtube.com/*` üzerinde çalışır.
- Sayfada `?v=<id>` veya `/shorts/<id>` varsa FAB görünür; yoksa gizlenir.
- Tıklama → `https://youtube.sentroy.com/watch?v=<id>` (downloader otomatik metadata çeker).
- İzin minimal: yalnızca `activeTab` (popup'ın aktif sekme URL'sini okuması için). Veri toplamaz, harici istek atmaz; sadece bir sekme açar.

## Lokal test (load unpacked)
1. Chrome → `chrome://extensions`
2. Sağ üstten **Developer mode** aç.
3. **Load unpacked** → bu klasörü (`downloader-extension/`) seç.
4. youtube.com'da bir video aç → sağ altta kırmızı indir butonu görünür.

## Chrome Web Store'da yayınlama
1. **Paketle:** klasörün içeriğini zip'le (klasörü değil, içindeki dosyaları kökte):
   ```bash
   cd downloader-extension && zip -r ../sentroy-downloader-extension.zip . -x ".*"
   ```
2. **Developer hesabı:** https://chrome.google.com/webstore/devconsole (tek seferlik 5$ kayıt ücreti).
3. **New item** → zip'i yükle.
4. **Store listing** doldur:
   - Name: `Sentroy Downloader for YouTube`
   - Summary (132 char): `Download YouTube & YouTube Music as MP4 or MP3 with one click.`
   - Description: aşağıdaki taslağı kullan.
   - Category: `Productivity` (veya `Tools`).
   - Screenshots: 1280×800 veya 640×400 (FAB'ın göründüğü bir YouTube ekran görüntüsü).
   - Icon: 128×128 (icons/icon128.png).
5. **Privacy:**
   - Single purpose: "Add a one-click download button to YouTube that opens the video on youtube.sentroy.com."
   - Permission justification — `activeTab`: "Read the current tab's URL to build the download link when the user clicks the popup button."
   - Data usage: "Does not collect or transmit user data."
6. **Submit for review.** (İnceleme genelde birkaç gün.)

### Açıklama taslağı (store description)
> Add a clean, icon-only download button to every YouTube and YouTube Music video.
> One click opens the video on youtube.sentroy.com, where you can save it as MP4
> (up to 1080p) or convert to MP3 — free, no signup, no ads. The button appears
> only on video pages and the extension requests no broad permissions.

## Sürüm yükseltme
`manifest.json` içindeki `version`'ı artır, yeniden zip'le, devconsole'dan yeni paket yükle.

## Yasal not
Kullanıcılar yalnızca sahibi oldukları veya izinli oldukları içeriği indirmelidir; her platformun hizmet şartlarına uymak kullanıcının sorumluluğundadır. Eklenti yalnızca bir bağlantı açar; indirme işlemi Sentroy tarafında yapılır.
