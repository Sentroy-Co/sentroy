/**
 * Sentroy Downloader — içerik scripti.
 * YouTube / YouTube Music (watch + Shorts) ve Instagram (reel / gönderi / IGTV /
 * story) sayfalarında ikon-only kırmızı yuvarlak indir butonu (FAB) gösterir.
 * Tıklayınca o içeriği ilgili sentroy alt-alanında yeni sekmede açar.
 *
 * Her ikisi de SPA — URL değişimlerinde (event + URL gözlemi) güncellenir.
 */
(function () {
  const FAB_ID = "sentroy-dl-fab"
  const IG_CONTENT = /^\/(p|reel|reels|tv|stories)\/[^/]+/i

  // İkon-only: kırmızı yuvarlak buton içinde beyaz indirme oku (inline SVG).
  const DOWNLOAD_SVG =
    '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
    '<path d="M12 3v12m0 0l-4.5-4.5M12 15l4.5-4.5" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>' +
    '<path d="M4 17v1.5A2.5 2.5 0 0 0 6.5 21h11a2.5 2.5 0 0 0 2.5-2.5V17" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>' +
    "</svg>"

  /** Geçerli sayfadan Sentroy indirme URL'si üret (yoksa null). */
  function targetUrl() {
    try {
      const u = new URL(location.href)
      const host = u.hostname
      // Instagram: reel / gönderi / IGTV / story → host'u sentroy yap (proxy
      // watch'a rewrite eder). Profil (bare /username) hariç.
      if (host.endsWith("instagram.com")) {
        if (IG_CONTENT.test(u.pathname)) {
          return `https://instagram.sentroy.com${u.pathname}`
        }
        return null
      }
      // YouTube: ?v= veya /shorts/<id>
      const v = u.searchParams.get("v")
      if (v) return `https://youtube.sentroy.com/watch?v=${encodeURIComponent(v)}`
      const m = u.pathname.match(/^\/shorts\/([\w-]{6,})/)
      if (m) return `https://youtube.sentroy.com/watch?v=${encodeURIComponent(m[1])}`
    } catch (_) {
      /* yoksay */
    }
    return null
  }

  function ensureButton() {
    let btn = document.getElementById(FAB_ID)
    if (btn) return btn
    btn = document.createElement("button")
    btn.id = FAB_ID
    btn.type = "button"
    btn.title = "Download with Sentroy"
    btn.setAttribute("aria-label", "Download with Sentroy")
    btn.innerHTML = DOWNLOAD_SVG
    btn.addEventListener("click", function (e) {
      e.preventDefault()
      e.stopPropagation()
      const target = targetUrl()
      if (target) window.open(target, "_blank", "noopener,noreferrer")
    })
    document.body.appendChild(btn)
    return btn
  }

  function update() {
    const target = targetUrl()
    const existing = document.getElementById(FAB_ID)
    if (target) {
      const btn = ensureButton()
      btn.style.display = "flex"
    } else if (existing) {
      existing.style.display = "none"
    }
  }

  // İlk çalıştırma + SPA navigasyon dinleyicileri.
  update()
  document.addEventListener("yt-navigate-finish", update)
  document.addEventListener("yt-page-data-updated", update)

  let lastUrl = location.href
  const obs = new MutationObserver(function () {
    if (location.href !== lastUrl) {
      lastUrl = location.href
      update()
    }
  })
  obs.observe(document.documentElement, { subtree: true, childList: true })
})()
